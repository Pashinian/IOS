
/*var altura = 5
var base = 7

var area = altura * base
var perimetro = (altura + base)*2

print("area es " , area)
print("perimetro es " , perimetro)
 */

/*import Foundation
let c1 = 4
var c2 = 5

var c12 = pow(Double(c1),2)
var c22 = pow(Double(c2),2)
var h = sqrt((Double(c12)+Double(c22)))


print(h)
 */

/*var uno = 5
var dos = 9

print(uno + dos)
print(uno - dos)
print(uno * dos)
print(uno / dos)
 */

/*var faren = 80

var celsius = ((Double(faren)-32)*5/9)
print(celsius)*/

/*let sueldob = Double(1600)
let ventas = 200
let comision3 = (Double(ventas) * 0.10) * 3
var sueldot = sueldob + comision3
print(comision3)
print(sueldot)*/

/*let parcial1 = Double(6)
let parcial2 = Double(7)
let parcial3 = Double(8)
let exf = Double(8)
let trf = Double(6)
var porpar = ((parcial1 + parcial2 + parcial3)/3) * 0.55
var porexf = exf * 0.3
var portrf = trf * 0.15

print(porpar + porexf + portrf)*/

/*let correctas = 7
let incorrectas = 2
let blanco = 1

var suma = (7 * 5) + (2 * -1)
print((suma*10)/50)
*/

/*let sueldo = 1600
let horas = 10

print(sueldo+(horas * 5))
 */

/*var num = 0
if num < 0{
    print("numero negativo")
}
else if num > 0 {
    print("numero positivo")
}
else{
    print("numero es 0")
}
*/

/*var num = 5
if num % 2 == 0{
   print("Numero Par")
}
else{
    print("Numero Impar")
}
 */

/*let usuario = "pepe"
let cont = "pepe"

if usuario == "pepe" && cont == "pepe"{
    print("Estas Dentro")
}
else{
    print("Incorrecto")
}
 */

/*
import UIKit
var cadena = "soy pepe"
if cadena.contains("") {
    print(cadena)
}
else{
    print("Incorrecto")
}
 */

/*
let num1 = 90
let num2 = 100
let num3 = 200

if num1 > num2 && num2 > num3{
    print(num1, num2, num3)
}
if num1 > num2 && num2 < num3{
    print(num1, num3, num2)
}
if num1 < num2 && num2 > num3{
    print(num2, num1, num3)
}
if num1 < num2 && num2 < num3{
    print(num3, num2, num1)
}*/

/*let numbers = [10,9,8,7,6,5,4,3,2,1]
var sum = 0

for number in numbers {
    sum += number
}
print("suma" ,sum)
print("media" ,sum/10)
 */

/*var num1 = 50
var num2 = 1

for nums in num2...num1  {
    print(nums)
}
 */

/*let horas: [Int] = [9,10,5,8,9,9]
var sum = 0
for total in horas {
    sum += total
}
var sueldo = sum * 30
print(sueldo)*/

/*var factorial = 20
var resultado = 1
for n in 1...factorial{
    resultado *= n
}
print(resultado)*/





