class Ordenador{
    var nombre : String = ""
    var precio : Int = 0
    var ram = Ram()
    var procesador = Procesador()
    var almacenamiento = Almacenamiento()
    var grafica = Grafica()
}

class Ram{
    var listaRam : [String] = ["Modulo 1", "Modulo 2"]
    var gigas = "8GB"
    var marca = "Crucial"
    var led = "Si"
    
    var gigas1 = "16GB"
    var marca1 = "Crucial"
    var led1 = "Si"
}
class Procesador{
    var velocidad = "3.2GHz"
    var core = "4"
    var threads = "8"
    var marca = "intel"
}
class Almacenamiento{
    var listaDisco : [String] = ["Disco 1", "Disco 2"]
    
    var capacidad = "500GB"
    var marca = "Western Digital"
    var tipo = "SSD"
    
    var capacidad1 = "1000GB"
    var marca1 = "Western Digital"
    var tipo1 = "HDD"
}
class Grafica{
    var ram = "4GB"
    var consumo = "10mAh"
    var cudacores = "4"
    var velocidad = "4GHz"
}

var ordenador = Ordenador()
ordenador.precio = 600
ordenador.nombre = "Luis"

print("Ordenador", ordenador.nombre, "precio de", ordenador.precio, "euros.", "Ram", ordenador.ram.listaRam[0], ordenador.ram.gigas, "fabricada por" ,ordenador.ram.marca, "contiene RGB", ordenador.ram.led, ordenador.ram.listaRam[1],ordenador.ram.gigas1, "fabricada por" ,ordenador.ram.marca1, "contiene RGB", ordenador.ram.led1, "Procesador, velocidad de", ordenador.procesador.velocidad,"Core",ordenador.procesador.core,"Hilos",ordenador.procesador.threads,"Marca",ordenador.procesador.marca,"Almacenamiento",ordenador.almacenamiento.listaDisco[0], ordenador.almacenamiento.capacidad, "Marca", ordenador.almacenamiento.marca, "Tipo" , ordenador.almacenamiento.tipo,ordenador.almacenamiento.listaDisco[1],ordenador.almacenamiento.capacidad1, "Marca", ordenador.almacenamiento.marca1, "Tipo" , ordenador.almacenamiento.tipo1, "Ram Grafica", ordenador.grafica.ram ,"consume", ordenador.grafica.consumo ,"Core",ordenador.grafica.cudacores ,"velocidad de", ordenador.grafica.velocidad)
